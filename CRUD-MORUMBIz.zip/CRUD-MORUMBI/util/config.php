<?php

//Configurar essas variáveis de acordo com o seu ambiente
define("DB_HOST", "mysql-server");
define("DB_NAME", "visitamorumbi");
define("DB_USER", "root");
define("DB_PASSWORD", "");

//Constante com a URL do sistema
define("BASE_URL", "/htdocs/crud_morumbi");